package com.xust.ffms.entity;

public class ProductType {
    private String code;
    private String name;

    public ProductType() {
    }

    public ProductType(String code, String name) {
        this.code = code;
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
